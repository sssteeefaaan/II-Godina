﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            OracleConnection con = null;
            string conString = "Data Source = 160.99.9.139/GISLAB; User Id = S1010; Password = S1010;";
            
            try
            {
                //otvaramo konekciju ka bazi podataka
                con = new OracleConnection(conString);
                con.Open();

                //pripremamo komandu koja ce za zadati tip odrediti broj filmova
                string strSQL = "SELECT BROJ, IME, PREZIME, ADRESA FROM CLAN";
                
                OracleCommand cmd = new OracleCommand(strSQL, con);
                cmd.CommandType = System.Data.CommandType.Text;

                //izvrsavamo komandu i u DataReader prihvatamo informacija o clanovima video kluba
                OracleDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        int broj = dr.GetInt32(0);
                        string ime = dr.GetString(1);
                        string prezime = dr.GetString(2);
                        string adresa = dr.GetString(3);

                        Console.WriteLine(broj.ToString() + "\t" + ime + "\t" + prezime + "\t" + adresa);
                    }
                }
                else
                {
                    Console.WriteLine("U bazi podataka ne postoje informacije o clanovima video kluba!");
                }

                dr.Close();

            }
            catch(Exception ec)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ec.Message);
            }
            finally
            {
                if (con != null && con.State == System.Data.ConnectionState.Open)
                    con.Close();

                con = null;
            }
        }
    }
}
