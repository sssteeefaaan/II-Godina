﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;

namespace Zadatak3
{
    class Program
    {
        static void Main(string[] args)
        {
            OracleConnection con = null;
            string conString = "Data Source = 160.99.9.139/GISLAB; User Id = S1010; Password = S1010;";

            try
            {
                //ucitavamo informacije o broju clana
                Console.WriteLine("Uneti broj clana za koga se kreira spisak:");
                int broj = Int32.Parse(Console.ReadLine());

                //otvaramo konekciju ka bazi podataka
                con = new OracleConnection(conString);
                con.Open();

                //pripremamo komandu koja ce za zadati broj odrediti spisak iznajmljenih filmova
                //kada se kreiraju komplikovaniji upit koristi se StringBuilder
                //jer je u tim slucajevima efikasniji
                StringBuilder strSQL = new StringBuilder();

                strSQL.Append("SELECT IZNAJMLJIVANJE.BROJ, FILM.BROJ, FILM.NASLOV, IZNAJMLJIVANJE.DATUM_IZNAJMLJIVANJA ");
                strSQL.Append(" FROM FILM, IZNAJMLJIVANJE ");
                strSQL.Append(" WHERE FILM.BROJ = IZNAJMLJIVANJE.FILM ");
                strSQL.Append(" AND IZNAJMLJIVANJE.DATUM_VRACANJA IS NULL ");
                strSQL.Append(" AND IZNAJMLJIVANJE.CLAN = :broj ");

                OracleCommand cmd = new OracleCommand(strSQL.ToString(), con);
                cmd.CommandType = System.Data.CommandType.Text;

                //kreiramo odgovarajuci parametar
                OracleParameter paramBroj = new OracleParameter("broj", OracleDbType.Int32);
                paramBroj.Value = broj;

                //dodajemo parametar u listu
                cmd.Parameters.Add(paramBroj);


                //izvrsavamo komandu i u DataReader prihvatamo informacija o filmovima
                OracleDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        int brojIznajmljivanja = dr.GetInt32(0);
                        int brojFilma = dr.GetInt32(1);
                        string naslov = dr.GetString(2);
                        DateTime datumIznajmljivanja = dr.GetDateTime(3);
                        
                        Console.WriteLine(brojIznajmljivanja.ToString() + " " 
                                            + brojFilma.ToString() + " " + naslov.ToString()
                                            + " " + datumIznajmljivanja.ToString("dd/MM/yyyy"));
                    }
                }
                else
                {
                    Console.WriteLine("Clan nema nijedan iznajmljeni film!");
                }

                dr.Close();

            }
            catch (Exception ec)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ec.Message);
            }
            finally
            {
                if (con != null && con.State == System.Data.ConnectionState.Open)
                    con.Close();

                con = null;
            }
        }
    }
}
