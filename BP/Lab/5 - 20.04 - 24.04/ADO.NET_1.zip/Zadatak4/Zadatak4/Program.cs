﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;

namespace Zadatak4
{
    class Program
    {
        static void Main(string[] args)
        {
            OracleConnection con = null;
            string conString = "Data Source = 160.99.9.139/GISLAB; User Id = S1010; Password = S1010;";

            try
            {
                //ucitavamo informacije o broju filma
                Console.WriteLine("Uneti broj filma:");
                int brojFilma = Int32.Parse(Console.ReadLine());

                //ucitavamo informacije o broju kopija
                Console.WriteLine("Uneti broj novih kopija:");
                byte brojKopija = Byte.Parse(Console.ReadLine());

                //otvaramo konekciju ka bazi podataka
                con = new OracleConnection(conString);
                con.Open();

                //pripremamo komandu koja ce modifikovati broj kopija
                string strSQL = "UPDATE FILM "
                                + " SET BROJ_DISKOVA = BROJ_DISKOVA + " + brojKopija.ToString()
                                + " WHERE BROJ = " + brojFilma.ToString();

                OracleCommand cmd = new OracleCommand(strSQL, con);
                cmd.CommandType = System.Data.CommandType.Text;

                //izvrsavamo komandu
                cmd.ExecuteNonQuery();

                Console.WriteLine("Komanda je uspesno izvrsena. Film je azuriran.");

            }
            catch (Exception ec)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ec.Message);
            }
            finally
            {
                if (con != null && con.State == System.Data.ConnectionState.Open)
                    con.Close();

                con = null;
            }
        }
    }
}
