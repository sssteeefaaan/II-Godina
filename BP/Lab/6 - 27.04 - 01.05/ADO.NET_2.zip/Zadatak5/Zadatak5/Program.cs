﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;
using System.Data;

namespace Zadatak5
{
    class Program
    {
        static void Main(string[] args)
        {
            //definise se connection string za ORACLE
            string strConnection = "Data Source=160.99.9.199/gislab.elfak.ni.ac.rs;User Id=aca;Password=aca;";

            OracleConnection con = null;
            OracleTransaction tran = null;

            try
            {


                //kreira se novi connection objekat
                con = new OracleConnection(strConnection);

                //uspopstavlja se konekcija sa bazom podataka
                con.Open();

                //upit koji ocitava podatke o filmovima
                string strSQL = "DELETE FROM FILM WHERE BROJ = :broj_filma";

                //sa standardnog ulaza se ocitava broj filma koji se brise
                Console.WriteLine("Unesite broj filma koji se brise:");
                int broj_filma = Int32.Parse(Console.ReadLine());

                //kreira se Command objekat
                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = strSQL;
                cmd.Connection = con;

                //kreira se parametar komande
                OracleParameter paramBroj = new OracleParameter();
                paramBroj.ParameterName = "broj_filma";
                paramBroj.OracleDbType = OracleDbType.Decimal;
                paramBroj.Value = (decimal)broj_filma;

                cmd.Parameters.Add(paramBroj);

                //startuje se transakcija
                tran = con.BeginTransaction();

                //izvrsava se komanda
                cmd.ExecuteNonQuery();

                //u slucaju uspeha transakcija se komituje
                //za transakcije koje traju jako dugo mogu se snimati check pointi koriscenjem metode Save()
                tran.Commit();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ex.Message);

                //ukoliko transakcije postoji ponistavaju se njeni efekti
                tran.Rollback();
                tran = null;

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }

                con = null;
            }
        }
    }
}
