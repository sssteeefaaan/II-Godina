﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;
using System.Data;

namespace Zadatak3
{
    class Program
    {
        static void Main(string[] args)
        {
            //definise se connection string za ORACLE
            string strConnection = "Data Source=160.99.9.199/gislab.elfak.ni.ac.rs;User Id=S1010;Password=S1010;";

            OracleConnection con = null;

            try
            {


                //kreira se novi connection objekat
                con = new OracleConnection(strConnection);

                //uspopstavlja se konekcija sa bazom podataka
                con.Open();

                //upit koji ocitava podatke o filmovima
                string strSQL = "SELECT * FROM FILM";

                //priprema se DataAdapter za ucitavanje filmova
                OracleDataAdapter da = new OracleDataAdapter(strSQL, con);
                OracleCommandBuilder builder = new OracleCommandBuilder(da);

                //kreira se novi DataSet i puni podacima
                DataSet ds = new DataSet();
                da.Fill(ds, "FILMOVI");

                //sa stanardnog ulaza ucitavamo informacije o filmu
                Console.WriteLine("Unesite naslov filma:");
                string naslov = Console.ReadLine();

                Console.WriteLine("Unesite tip filma:");
                string tip = Console.ReadLine();

                Console.WriteLine("Unesite godinu snimanja filma:");
                short godina = Int16.Parse(Console.ReadLine());

                Console.WriteLine("Unesite broj kopija:");
                short kopije = Int16.Parse(Console.ReadLine());

                Console.WriteLine("Unesite ime rezisera:");
                string ime = Console.ReadLine();

                Console.WriteLine("Unesite prezime rezisera:");
                string prezime = Console.ReadLine();

                //iz baze podataka ucitavamo informaciju o broju rezisera
                strSQL = "SELECT BROJ FROM REZISER WHERE IME = :imeR AND PREZIME = :prezimeR";

                OracleCommand cmdReziserBroj = new OracleCommand(strSQL, con);

                OracleParameter param1 = new OracleParameter("imeR", OracleDbType.Varchar2);
                OracleParameter param2 = new OracleParameter("prezimeR", OracleDbType.Varchar2);

                param1.Value = ime;
                param2.Value = prezime;

                cmdReziserBroj.Parameters.Add(param1);
                cmdReziserBroj.Parameters.Add(param2);

                int brojRezisera = (int)cmdReziserBroj.ExecuteScalar();


                //iz baze podataka ocitavamo sledeci broj koji treba dodeliti filmu
                strSQL = "SELECT MAX(BROJ) FROM FILM";

                OracleCommand cmdFilmBroj = new OracleCommand(strSQL, con);

                decimal brojFilma = (decimal)cmdFilmBroj.ExecuteScalar();


                //dodavanje novog filma
                DataRow rNew = ds.Tables["FILMOVI"].Rows.Add();

                rNew["BROJ"] = brojFilma + 1;
                rNew["NASLOV"] = naslov;
                rNew["TIP"] = tip;
                rNew["GODINA"] = godina;
                rNew["REZISER"] = brojRezisera;
                rNew["BROJ_DISKOVA"] = kopije;
                
                //izmene prenosimo u bazu
                da.Update(ds, "FILMOVI");

                Console.WriteLine("Podaci o filmu su uspesno uneti!");
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ex.Message);

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }

                con = null;
            }
        }
    }
}
