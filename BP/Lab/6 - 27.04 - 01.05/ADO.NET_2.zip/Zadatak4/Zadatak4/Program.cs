﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;
using System.Data;

namespace Zadatak4
{
    class Program
    {
        static void Main(string[] args)
        {
            //definise se connection string za ORACLE
            string strConnection = "Data Source=160.99.9.199/gislab.elfak.ni.ac.rs;User Id=S1010;Password=S1010;";

            OracleConnection con = null;

            try
            {


                //kreira se novi connection objekat
                con = new OracleConnection(strConnection);

                //uspopstavlja se konekcija sa bazom podataka
                con.Open();

                //upit koji ocitava podatke o filmovima
                string strSQL = "SELECT * FROM FILM";

                //priprema se DataAdapter za ucitavanje filmova
                OracleDataAdapter da = new OracleDataAdapter(strSQL, con);
                da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                OracleCommandBuilder builder = new OracleCommandBuilder(da);

                //kreira se novi DataSet i puni podacima
                DataSet ds = new DataSet();
                da.Fill(ds, "FILMOVI");

                //podaci su ucitani u DataSet pa moze da se prekine konekcija sa bazom podataka
                con.Close();


                //sa standardnog ulaza ocitavamo informaciju o broju film akoji brisemo
                Console.WriteLine("Broj filma koji se brise:");
                int brojFilma = Int32.Parse(Console.ReadLine());


                DataTable dtFilmovi = ds.Tables["FILMOVI"];
                DataRow r = dtFilmovi.Rows.Find((object)brojFilma);

                if (r != null)
                {
                    r.Delete();

                    da.Update(ds, "FILMOVI");

                    Console.WriteLine("Brisanje je uspesno obavljeno!");
                }
                else
                {
                    Console.WriteLine("Uneli ste broj nepostojeceg filma!");
                }

               
            }
            catch (Exception ex)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ex.Message);

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }

                con = null;
            }
        }
    }
}
