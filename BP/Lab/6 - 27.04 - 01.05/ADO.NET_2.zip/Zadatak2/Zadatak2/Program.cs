﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Oracle.DataAccess.Client;

namespace Zadatak2
{
    class Program
    {
        static void Main(string[] args)
        {
            //definise se connection string za ORACLE
            string strConnection = "Data Source=160.99.9.199/gislab.elfak.ni.ac.rs;User Id=S1010;Password=S1010;";

            OracleConnection con = null;

            try
            {


                //kreira se novi connection objekat
                con = new OracleConnection(strConnection);

                //uspopstavlja se konekcija sa bazom podataka
                con.Open();

                //upit koji ocitava podatke o filmovima
                string strSQL = "SELECT * FROM FILM";

                //priprema se DataAdapter za ucitavanje filmova
                OracleDataAdapter da = new OracleDataAdapter(strSQL, con);

                //kreira se novi DataSet i puni podacima
                DataSet ds = new DataSet();
                da.Fill(ds, "FILMOVI");

                //podaci su ucitani u DataSet pa moze da se prekine konekcija sa bazom podataka
                con.Close();

                DataTable dtFilmovi = ds.Tables["FILMOVI"];


                //sa standardnog ulaza se ocitava informacija o godini snimanja filma
                Console.WriteLine("Uneti podatak o granicnoj godini:");
                int godina = Int32.Parse(Console.ReadLine());

                //filtriramo podatke i sortiramo ih po godini snimanja filma
                DataRow [] filteredRows = dtFilmovi.Select("GODINA >= " + godina.ToString(), "GODINA ASC"); 

                //svim randicima cija je plata manja od prosecne plata se postavlja na iznos prosecne
                foreach (DataRow r in filteredRows)
                {
                    int broj = (int)r["BROJ"];
                    string naslov = (string)r["NASLOV"];
                    short godinaSnimanja = (short)r["GODINA"];

                    Console.WriteLine(broj + " " + naslov + " " + godinaSnimanja); 

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Doslo je do greske prilikom pristupanja bazi podataka: " + ex.Message);

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }

                con = null;
            }
        }
    }
}
