/*

Poigrati se sa byte tokovima... upisati nešto, pročitati nešto...

*/