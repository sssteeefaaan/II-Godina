/*

Kreirati javnu klasu Vektor u paketu nizovi koja sadrži privatne atribute:
- dimenziju vektora, i
- vektor podataka tipa float,
kao i javne metode za:
- učitavanje vektora iz tekstualne datoteke,
- učitavanje vektora iz binarne datoteke,
- upis vektora u tekstualnu datoteku,
- upis vektora u binarnu datoteku, i
- uređivanje vektora u neopadajući redosled.
U funkciji main (članici neke klase koja je definisana izvan paketa nizovi)
kreirati 2 objekta tipa Vektor. U prvi učitati vektor iz tekstualne datoteke
"Neuredjen.txt", urediti ga i upisati u binarnu datoteku "Uredjen.dat".
Zatim u drugi vektor učitati niz iz datoteke "Uredjen.dat" i upisati ga u
tekstualnu datoteku "Uredjen.txt".


*/