
public class TextZadatka {

}

/*

Ucitati nesto sa tastature i to isto ispisati na ekranu.

*/
