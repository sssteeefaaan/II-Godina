
public class TextZadatka {

}

/*

Kreirati javnu klasu Vektor u paketu nizovi koja sadrzi privatne atribute:
- dimenziju vektora, i
- vektor podataka tipa float,
kao i javne metode za:
- ucitavanje vektora iz tekstualne datoteke,
- ucitavanje vektora iz binarne datoteke,
- upis vektora u tekstualnu datoteku,
- upis vektora u binarnu datoteku, i
- uredjivanje vektora u neopadajuci redosled.
U funkciji main (clanici neke klase koja je definisana izvan paketa nizovi)
kreirati 2 objekta tipa Vektor. U prvi ucitati vektor iz tekstualne datoteke
"Neuredjeni.txt", urediti ga i upisati u binarnu datoteku "Uređeni.dat".
Zatim u drugi vektor ucitati niz iz datoteke "Uredjeni.dat" i upisati ga u
tekstualnu datoteku "Uredjeni.txt".


*/