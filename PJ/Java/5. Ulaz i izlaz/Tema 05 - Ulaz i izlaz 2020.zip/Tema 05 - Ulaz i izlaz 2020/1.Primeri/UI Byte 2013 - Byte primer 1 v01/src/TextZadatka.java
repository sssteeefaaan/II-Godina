
public class TextZadatka {

}

/*

Poigrati se sa byte tokovima... upisati nesto, procitati nesto...

*/