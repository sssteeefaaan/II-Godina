
public class TextZadatka {

}

/*

U paketu ulazizlaz kreirati klasu Citac izvedenu iz klase BufferedReader
i u njoj definisati konstruktor sa argumentom tipa Reader, kao i funkcije:
- procitajInt(),
- procitajFloat() i
- procitajDouble()
koje ucitavaju po 1 podatak odgovarajućeg tipa iz ulaznog tekstualnog toka.
U funkciji main (clanici klase koja je definisana izvan paketa ulazizlaz)
koriscenjem objekta klase TypeReader ucitati niz podataka tipa float iz
datoteke FNiz.txt i niz podataka tipa double sa standardnog ulaza. Brojeve
elemenata u nizovima citati sa istog resursa odakle se ucitavaju i sami
elementi. Na standardni izlaz stampati sume elemenata oba niza.


*/