
public class Glavna {
	
	public static void main (String[] args) {
        new NitKaoNaslednica("Lada").start();
        new NitKaoNaslednica("Stojadin").start();
    }

}
