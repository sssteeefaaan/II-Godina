
public class TextZadatka {

}

/*

Klasa za razlomak. Konstruktor ce da baci izuzetak
ako je razlomak nedefinisan (ako mi se za imenliac
posalje nula). Baca bibliotecki tip izuzetka
(Exception).

*/