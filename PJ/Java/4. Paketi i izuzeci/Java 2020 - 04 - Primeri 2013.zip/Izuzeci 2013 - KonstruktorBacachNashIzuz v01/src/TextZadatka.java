
public class TextZadatka {

}

/*

Klasa za razlomak. Konstruktor ce da baci izuzetak
ako je razlomak nedefinisan (ako mi se za imenliac
posalje nula).

Sami pravimo klasu za izuzetke, pa konstruktor baca
izuzetak tipa te nase klase.

*/