
public class TextZadatka {

}

/*

U paketu kolekcije kreirati javnu klasu Magacin koja
modelira magacin u koji mogu da se upisuju podaci
proizvoljnog tipa. Klasa treba da sadrzi javne funkcije:
push - za upis elementa u magacin, 
pop - za izbacivanje elementa iz magacina i 
prazanJe - za ispitivanje da li je magacin prazan. 
Magacin realizovati pomocu lancane liste.

U metodu main (klase koja je definisana van paketa kolekcije),
kreirati objekat klase Magacin, upisati u njega 10 slucajnih
celih brojeva, isprazniti stek i vrednost svakog izbacenog
elementa stampati na standardni izlaz. Voditi racuna o tome
da je klasa prilagodjena proizvoljnom tipu – kakvi tipovi dolaze
u obzir, primitivni ili referentni?


*/