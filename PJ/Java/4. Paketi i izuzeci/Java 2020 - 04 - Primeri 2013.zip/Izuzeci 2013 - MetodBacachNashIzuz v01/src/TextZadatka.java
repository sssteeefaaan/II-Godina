
public class TextZadatka {

}

/*

Klasa za razlomak. Konstruktor ce da baci izuzetak
ako je razlomak nedefinisan (ako mi se za imenliac
posalje nula).

Za izuzetke pravimo neku nasu klasu, tako da metod
baca izuzetak tipa te nase klase.

*/