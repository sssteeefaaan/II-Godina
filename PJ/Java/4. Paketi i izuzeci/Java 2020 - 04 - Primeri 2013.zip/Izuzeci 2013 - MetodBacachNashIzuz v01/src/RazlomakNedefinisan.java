
public class RazlomakNedefinisan extends Exception {
	
	static final long serialVersionUID=0;	// ovo mi je Eclipse trazio pa sam napisao.
	
	public RazlomakNedefinisan()
	{
		super("mani se te nule!");
	}

}
