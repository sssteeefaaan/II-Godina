package matematika;

public interface Funkcija {
	
	double vrednost(double x);
	boolean imaRealneNule();
	double[] nule();

}
