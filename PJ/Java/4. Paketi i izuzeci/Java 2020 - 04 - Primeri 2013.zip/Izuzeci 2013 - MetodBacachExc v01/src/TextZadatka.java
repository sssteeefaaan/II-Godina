
public class TextZadatka {

}

/*

Klasa za razlomak. Metod koji racuna vrednost
razlomka baca izuzetak ako je razlomak nedefinisan
(ako mu je imenilac jednak nuli).

Baca bibliotecki tip izuzetka (Exception).

*/