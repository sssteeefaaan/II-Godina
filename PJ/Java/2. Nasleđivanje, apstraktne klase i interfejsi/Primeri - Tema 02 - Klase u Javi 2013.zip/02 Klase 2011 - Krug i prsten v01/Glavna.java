
public class Glavna 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Prsten p1;
		p1=new Prsten(3.0f,2.0f);
		System.out.println("Povrsina prstena je :" + p1.povrsina());
	}

}
