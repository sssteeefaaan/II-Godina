
public class Krug {
	
	protected float poluprecnik ;
	
	static final float pi = 3.14f;	// Slovo f da bi se konstanta 3.14
									// tretirala kao float a ne double.
	
	// Konstruktor sa jednim argumentom tipa float, sa namenom da
	// postavi vrednost za poluprecnik svakom novokreiranom objektu.
	// Konkretna vrednost za poluprecnik konstruktoru se dodaje kroz
	// argument operatora new, na mestu gde se kreira objekat.
	public Krug (float p1)
	{
		poluprecnik = p1;
	}
	
	// Metod koji vraca povrsinu kruga.
	float povrsina()
	{
		float pov;
		pov = poluprecnik * poluprecnik * pi;
		return pov;
	}
}

//Metod main nalazi se u drugoj klasi (klasi "Glavna").
