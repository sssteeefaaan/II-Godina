
public class Prsten extends Krug
{
	private float unutrasnjiPoluprecnik;
	
	public Prsten(float r1, float r2)
	{
		super(r1);
		unutrasnjiPoluprecnik = r2;
	}
	
	float povrsina()
	{
		float povrsinaCelog;
		float povrsinaUnutrasnjeg;
		povrsinaCelog = super.poluprecnik * super.poluprecnik * pi;
		povrsinaUnutrasnjeg = unutrasnjiPoluprecnik * unutrasnjiPoluprecnik * pi;
		return povrsinaCelog - povrsinaUnutrasnjeg;
	}
}
