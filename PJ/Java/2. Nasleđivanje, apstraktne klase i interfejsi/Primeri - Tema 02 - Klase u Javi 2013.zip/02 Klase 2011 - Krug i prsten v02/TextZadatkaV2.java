
public class TextZadatkaV2 {
	
	public String tekstZadatka = "Citaj dole.";
	
}

/*

Kreirati klasu Krug koja sadrzi promenljivu objekta poluprecnik,
konstuktor koji postavlja poluprecnik i metodu za izracunavanje
povrsine kruga.
	
Kreirati i klasu Prsten izvedenu iz klase Krug, koja sadrzi atribut
tipa Krug za unutrašnji krug, konstruktor koji postavlja poluprecnike
spoljasnjeg i unutrasnjeg kruga i metod za izracunavanje povrsine kruznog
prstena.

*/
