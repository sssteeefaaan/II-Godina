
public class PrstenV2 extends KrugV2
{
	// Glavna razlika u odnosu na verziju 1 ovog zadatka je u tome
	// što ovde atribut u klasi Prsten nije poluprečnik unutrašnjeg
	// kruga, već ceo jedan objekat klase Krug... a koji nam u stvari
	// služi da definiše poluprečnik unutrašnjeg kruga. Ima istu
	// funkciju kao kada bismo koristili poluprečnik unutrašnjeg, samo
	// mu sada pristupamo kao objektu klase Krug.
	// Ova verzija služi da pokaže da se to može uraditi i ovako, jer
	// je ovakav pristup čest u praksi.
	KrugV2 unutrasnji;
	
	PrstenV2(float r1, float r2)
	{
		super(r1);
		unutrasnji = new KrugV2(r2);
	}
	
	float povrsina()
	{
		float temp;
		temp=super.povrsina() - unutrasnji.povrsina();
		return temp;
	}
}
