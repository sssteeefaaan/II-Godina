
public class KrugV2 {
	
	float poluprecnik ;
	
	static final float pi = 3.14f;
	
	KrugV2 (float p1)
	{
		poluprecnik = p1;
	
	}
	
	float povrsina()
	{
		float pov;
		pov=poluprecnik*poluprecnik*pi;
		return pov;
	}
}
