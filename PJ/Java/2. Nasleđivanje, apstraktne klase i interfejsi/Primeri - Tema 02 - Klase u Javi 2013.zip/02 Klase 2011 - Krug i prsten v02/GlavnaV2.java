
public class GlavnaV2 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		PrstenV2 p1;
		p1=new PrstenV2(3.0f,2.0f);
		System.out.println("Povrsina prstena je :" + p1.povrsina());
	}

}
