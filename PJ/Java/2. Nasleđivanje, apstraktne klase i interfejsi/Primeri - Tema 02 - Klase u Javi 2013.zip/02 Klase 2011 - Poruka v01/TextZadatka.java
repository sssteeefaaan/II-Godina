
public class TextZadatka {

}

/*

Kreirati klasu Poruka koja sadrzi:
artibut objekta – tekst poruke (tipa String),
atribut klase – broj kreiranih poruka (tipa int),
2 metoda objekta:
jedan koji postavlja sadrzaja poruke i inkrementira broj poruka i
jedan za prikaz sadrzaja poruke na standardni izlaz (ekran), i
metod main (on je uvek metod klase) u kome treba kreirati 3 objekta
klase Poruka, postaviti njihove sadrzaje i prikazati na standardni
izlaz sadrzaje svih poruka, a potom i ukupan broj kreiranih poruka.

*/
