
public class TextZadatka {

}

/*

Na programskom jeziku Java kreirati klasu Point. Klasa sadrži dva
zasticena atributa: koodrinate x i y i sledece javne funkcije clanice:
podrazumevani konstruktor koji inicijalizuje vrednosti koordinata na 0
konstruktor kojim se postavljaju vrednosti x i y
funkciju za odredjivanje rastojanja između dve tacke
funkciju printData za prikaz koordinata tacke na standardni izlaz

Iz klase Point izvesti klasu PointCity koja označava lokaciju grada na
geografskoj karti. Ova klasa sadrži privatne attribute:
naziv
broj stanovnika
Klasa sadrži i sledeće javne funkcije:
podrazumevani konstruktor
konstruktor kojim se postavljaju vrednosti svih atributa
funkciju printData koja, pored atributa roditeljske klase, štampa podatake
iz izvedene klase (naziv i broj stanovnika),

U funkciji main kreirati dva objekta klase CitiyPoint i na standardni izlaz
prikazatai podatke o njima njihovo rastojanje.


*/