
public class Point 
{
	protected float x;
	protected float y;
	
	public Point()
	{
		x = 0;
		y = 0;
	}
	
	public Point( float x, float y )
	{
		this.x = x;
		this.y = y;
	}
	
	public float distance( Point p )
	{
		return (float) Math.sqrt( (x-p.x)*(x-p.x)+(y-p.y)*(y-p.y));
	}
	
	public void printData()
	{
		System.out.println( "(" + x + "," + y + ")" );
	}
}
