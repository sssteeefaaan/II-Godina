
public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		CityPoint nis = new CityPoint( 300.0f, 200.0f, "Ni�", 200000 );
		CityPoint beograd = new CityPoint( 500.0f, 190.f, "Beograd", 2000000);
		
		nis.printData();
		beograd.printData();
		System.out.println("Rastojanje izmedju gradova je: " + nis.distance( beograd ));

	}

}
