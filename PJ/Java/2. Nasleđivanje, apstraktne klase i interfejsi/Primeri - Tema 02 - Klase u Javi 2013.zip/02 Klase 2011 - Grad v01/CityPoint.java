
public class CityPoint extends Point 
{
	String name;	//ime grada
	int number;		//broj stanovnika
	
	public CityPoint()
	{					
		/*implicitno se poziva konstruktor bez argumenata
		roditeljske klase*/
		name = null;
		number = 0;
	}
	
	public CityPoint( float x, float y, String cityName, int num)
	{
		super( x, y );
		name = cityName;
		number = num;
	}
	
	public void printData()
	{
		System.out.println( "Grad: " + name );
		System.out.println( "Broj stanovnika: " + number);
		System.out.print( "Koordinate: ");
		super.printData();
	}
}
