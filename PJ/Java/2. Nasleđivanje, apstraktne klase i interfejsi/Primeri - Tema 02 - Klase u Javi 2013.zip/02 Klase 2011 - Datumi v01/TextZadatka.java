
public class TextZadatka {

}

/*

Na programskom jeziku Java kreirati klasu Datum koja sadrzi:
atribute instanci: dan i mesec; atribut klase: indikator da li
je godina prestupna, metode instanci za: postavljanje tekuceg
datuma i prikaz datuma na standardni izlaz, metode klase za:
odredjivanje broja dana u zadatom mesecu, odredjivanje razlike
(u danima) izmedju dva datuma, uredjivanje 2 datuma u neopadajuci
redosled i medjusobnu razmenu vrednosti dvoma datumima.


*/
