package Interfejsi;

public interface IFactory {
    String getFactoryName();
    void startWork();
    void endWork();
}
