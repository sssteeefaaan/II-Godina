enum Kafa
{
	SLAĐA, SREDNJA, GORČA;
}
public class MainClass {
	
	public static void main (String args[])
	{
		Kafa k1 = Kafa.SREDNJA;
		System.out.println(k1);
	}

}
