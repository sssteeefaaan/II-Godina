
public class TextZadatka {

}

/*

Na programkom jeziku Java kreirati klasu Poruka koja sadrzi:
artibut instanci – tekst poruke,
atribut klase – broj kreiranih poruka,
konstruktor sa jednim atributom tipa String koji postavlja pocetnu
vrednost novom objektu i povecava za jedan broj kreiranih poruka,
metod instance za prikaz poruke na standardni izlaz,
metod main (on je uvek metod klase) u kome treba kreirati 3 objekta
klase Poruka, postaviti njihove sadrzaje i prikazati na standardni
izlaz sadrzaje svih poruka i ukupan broj kreiranih poruka.
 
POENTA:
Ovde smo postavljanje pocetne vrednosti novog objekta realizovali
pomocu konstruktora, a ne obicnog metoda.

*/