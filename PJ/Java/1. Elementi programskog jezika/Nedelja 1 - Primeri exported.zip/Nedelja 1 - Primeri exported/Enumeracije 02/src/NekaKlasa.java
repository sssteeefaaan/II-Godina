
public class NekaKlasa {
	
	enum Kafa { SLAĐA, SREDNJA, GORČA; }
	
	public static void main (String[] args)
	{
		Kafa k1 = Kafa.SLAĐA;
		System.out.println(k1);
	}

}
