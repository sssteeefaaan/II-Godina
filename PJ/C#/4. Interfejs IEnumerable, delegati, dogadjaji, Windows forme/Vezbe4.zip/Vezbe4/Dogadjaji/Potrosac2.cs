﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dogadjaji
{
    class Potrosac2
    {

        public void Metoda(int arg)
        {
            Console.WriteLine("Klasa Potrosac2, nova vrednost broja je: " + arg);
        }
    }
}
