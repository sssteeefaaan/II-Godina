﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dogadjaji
{
    class PotrosacDogadjaja
    {
        public void ObradaDogadjaja(int i)
        {
            Console.WriteLine("Broj je promenjen. Nova vrednost je: " + i);
        }
    }
}
