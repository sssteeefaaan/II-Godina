﻿
// Delegat preko kog klasa Put treba da upozori vozila na ograničenje mase vozila 
// na tom putu. 
public delegate void UpozorenjeNosivost(float limitMase);