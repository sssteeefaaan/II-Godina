#include "Greska.h"


Greska::Greska(void)
{
}


Greska::~Greska(void)
{
}
