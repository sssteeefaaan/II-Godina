#include "SquareTemplateMatrix.h"


