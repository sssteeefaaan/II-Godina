#include "XOMatrix.h"


XOMatrix::XOMatrix(void)
{
}


XOMatrix::~XOMatrix(void)
{
}
